package com.wn.dao.jdbcdao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * @author WN
 */
@Repository
public class TestJdbcTempDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private static  Logger logger = LoggerFactory.getLogger(TestJdbcTempDao.class);

    public int insertStudentInfo(){
        int result = 0;
        String sql = "UPDATE student SET NAME  = '16宁' WHERE ID = 3";
        logger.debug("执行sql"+sql);
        result = jdbcTemplate.update(sql);
        if(result == 1){
            throw new RuntimeException("抛异常，看事务会不会回滚");
        }
        return result;
    }
}
