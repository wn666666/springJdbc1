package com.wn.service;

import com.wn.dao.jdbcdao.TestJdbcTempDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TestService {

    @Autowired
    private TestJdbcTempDao testJdbcTempDao;

    public int insertStudentInfo(){
        int i = 0;
        try {
            i = testJdbcTempDao.insertStudentInfo();
        }catch (Exception e){
            throw new RuntimeException(e.getMessage());
        }
        return i;
    }
}
