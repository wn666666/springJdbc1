package cache;

import java.util.Map;

public class CacheContext<T> {
}
