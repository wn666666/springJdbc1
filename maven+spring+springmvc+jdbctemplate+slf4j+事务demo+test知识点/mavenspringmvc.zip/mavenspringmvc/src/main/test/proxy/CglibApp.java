package proxy;

public class CglibApp {
    public static void main(String[] args) {
        //目标对象
        CglibUserDao cglibUserDao = new CglibUserDao();
        //代理对象
        CglibUserDao proxy = (CglibUserDao) new CglibProxyFactory(cglibUserDao).getProxyInstance();
        System.out.println(proxy.getClass());
        //执行代理对象的方法
        proxy.save();
    }
}
