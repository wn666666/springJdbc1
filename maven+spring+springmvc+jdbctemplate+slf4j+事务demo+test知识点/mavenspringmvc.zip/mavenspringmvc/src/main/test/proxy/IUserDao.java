package proxy;

public interface IUserDao {
    void save();
}
