package proxy;

public class UserDaoImpl  implements IUserDao{
    @Override
    public void save() {
        System.out.println("---------已经保存的数据------------");
    }
}
