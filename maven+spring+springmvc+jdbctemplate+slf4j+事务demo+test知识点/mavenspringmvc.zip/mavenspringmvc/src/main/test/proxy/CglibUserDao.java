package proxy;

public class CglibUserDao {
    public void save(){
        System.out.println("保存的数据");
    }
}
