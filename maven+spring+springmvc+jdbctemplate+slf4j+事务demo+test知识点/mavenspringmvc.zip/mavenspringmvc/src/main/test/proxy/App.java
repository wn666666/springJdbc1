package proxy;

public class App {
    public static void main(String[] args) {
        //目标对象
        IUserDao target = new UserDaoImpl();
        //代理对象
        UserDaoProxy userDaoProxy = new UserDaoProxy(target);

        userDaoProxy.save();
    }
}
