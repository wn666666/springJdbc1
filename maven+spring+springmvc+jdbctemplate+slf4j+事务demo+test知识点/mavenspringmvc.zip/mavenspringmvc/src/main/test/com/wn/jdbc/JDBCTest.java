package com.wn.jdbc;

import com.wn.dao.jdbcdao.TestJdbcTempDao;
import com.wn.service.TestService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath*:conf/spring/applicationContext.xml"})
public class JDBCTest {
    //private static ApplicationContext ctx;
    @Autowired
    private TestService testService;

    /*public static void setBean() throws Exception{
        try {
            ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
            jdbcTempDao = (TestJdbcTempDao) ctx.getBean("testJdbcTempDao");
        }catch (Exception e){
            e.printStackTrace();
        }
    }*/
    @Test
    @Transactional
    //@Rollback(false)
    public void insert(){
         testService.insertStudentInfo();
    }

}
