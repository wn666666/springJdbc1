package singleton;

/**
 * @author WN
 * 静态内部类写法
 */
public class StaticClassSingleton {
    /**
     * 静态内部类
     * 只适用于静态域情况
     * 类加载机智保证初始化instance时候只有一个线程
     *
     */
    private static class StaticClassSingletonHolder{
        private static final StaticClassSingleton instance = new StaticClassSingleton() ;
    }
    private StaticClassSingleton(){

    };
    public static final StaticClassSingleton getInstance(){
        return StaticClassSingletonHolder.instance;
    }

}
