package singleton;

/**
 * @author WN
 * 饿汉式 单例
 */
public class HungSingleton {
    /**
     * 恶汉，一开始直接初始化bean，达不到懒加载 基于classlaoder机制避免多线程同步问题 线程安全
     * 容易产生垃圾对象
     */
    private static HungSingleton instance = new HungSingleton();
    private HungSingleton(){};

    /**
     * 不加锁 速度快效率高
     * @return
     */
    private static HungSingleton getInstance(){
        return instance;
    }
}
