package singleton;

/**
 * @author WN
 * 双重锁机制单例
 */
public class DoubleCheckSingleton {
    private static DoubleCheckSingleton instance;
    private DoubleCheckSingleton(){};

    /**
     * 双重锁
     * 线程安全 多线程下保持高性能
     * 主要用于getInstance（）的性能对应用程序很关键
     * @return
     */
    public static DoubleCheckSingleton getInstance(){
        if(instance == null){
            synchronized (DoubleCheckSingleton.class){
                if (instance == null){
                    instance = new DoubleCheckSingleton();
                }
            }
        }
        return instance;
    }
}
