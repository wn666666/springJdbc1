package singleton;

/**
 * @author WN
 * 懒汉式 线程安全 效率低 不提倡
 */
public class SaveSingleton {
    /**
     * 私有成员变量
     */
    private static SaveSingleton instance = null;

    /**
     * 私有构造器 必须私有
     */
    private SaveSingleton(){};

    /**
     * 提供给外部调用方法，线程锁 安全 效率低下
     * @return
     */
    public static synchronized SaveSingleton getInstance(){
        if(instance == null){
            instance = new SaveSingleton();
        }
        return instance;
    }
}
