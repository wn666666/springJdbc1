package singleton;

/**
 * @author WN
 * 懒汉单例  线程不安全
 */
public class Singleton {
    /**
     * 私有成员变量  懒汉式 不主动创建bean实例
     */
    private static Singleton instance = null;

    /**
     * 私有构造器 *****必须定义为私有 外部无法通过构造器创建实例
     */
    private Singleton(){};

    /**
     * 提供给外部调用的方法，唯一入口
     * @return
     */
    public static Singleton getInstance(){
        if(instance == null){
            return new Singleton();
        }else {
            return null;
        }
    }
}
