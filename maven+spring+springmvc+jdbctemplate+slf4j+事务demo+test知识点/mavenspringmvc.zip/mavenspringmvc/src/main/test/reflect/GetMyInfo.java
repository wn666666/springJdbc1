package reflect;

import com.sun.org.apache.bcel.internal.classfile.ClassFormatException;

import java.lang.reflect.*;

public class GetMyInfo {
    public static void main(String[] args) {
        try {
            Class myClass = Class.forName("reflect.UserInfo");
            System.out.println("类名："+myClass.getName());
            System.out.println("基础类简称："+myClass.getSimpleName());
            System.out.println("输出所有属性+++++++++++++++++++++++");
            Field[] fields = myClass.getDeclaredFields();
            for (Field field: fields
                 ) {
                String fieldName = field.getName();//属性名称
                int fieldVisit = field.getModifiers();//属性访问权限修饰符
                Class fieldType = field.getType();//属性类型
                System.out.println(Modifier.toString(fieldVisit)+","+fieldType.getName()+fieldName);
            }
            System.out.println("输出所有方法++++++++++++++++++++++++");
            Method[] methods = myClass.getMethods();
            for (Method method: methods
                 ) {
                String methodName = method.getName();
                int methodVisit = method.getModifiers();
                Class returnType = method.getReturnType();
                Class[] param = method.getParameterTypes();
                System.out.print(Modifier.toString(methodVisit)+returnType.getSimpleName()+" "+methodName
                +"(");
                for (int i = 0; i <param.length ; i++) {
                    String paramName = param[i].getSimpleName();
                    if(i != param.length-1){
                        System.out.print(paramName+"arg"+i+",");
                    }else {
                        System.out.print(paramName+"arg"+i);
                    }
                }
                System.out.println(")");
            }
            System.out.println("输出所有构造器+++++++++++++++++++++++++");
            Constructor[] constructors = myClass.getConstructors();
            for(Constructor constructor:constructors)
            {
                String constructorName = constructor.getName();
                Class[] constructorParameter = constructor.getParameterTypes();
                System.out.print(myClass.getSimpleName()+" "+constructorName.substring(constructorName.lastIndexOf(".")+1, constructorName.length())+"(");
                for(int h=0;h<constructorParameter.length;h++)
                {
                    String parameterName = constructorParameter[h].getSimpleName();
                    if(h!=constructorParameter.length-1)
                        System.out.print(parameterName+" arg"+h+",");
                    else
                        System.out.print(parameterName+" arg"+h);
                }
                System.out.println(");");

            }
            //如何执行指定方法
            System.out.println("反射执行方法+++++++++++++++");
            String name = "getMyInfo";
            Class[] paramTypes = new Class[3];
            paramTypes[0] = String.class;
            paramTypes[1] = String.class;
            paramTypes[2] = Integer.class;
            Method me;
            me = myClass.getDeclaredMethod(name,paramTypes);
            Object object = myClass.newInstance();
            Object[] objects = new Object[3];
            objects[0] = "111";
            objects[1] = "222";
            objects[2] = new Integer(3);
            me.invoke(object,objects);
        }catch (ClassFormatException e){
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

    }
}
