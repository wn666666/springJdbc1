package reflect;

public class UserInfo {
    public String userName;
    public int age;
    public String School;
    public UserInfo(String name,int age,String school){
        this.userName = name;
        this.age = age;
        this.School = school;
    }
    //构造器一定要写
    public UserInfo(){};
    public String getInfo(String name,int age){
        return "success"+name+age;
    }
    public void getMyInfo(String name,String school,Integer age){
        System.out.println(name+","+school+","+age);
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSchool() {
        return School;
    }

    public void setSchool(String school) {
        School = school;
    }
}
